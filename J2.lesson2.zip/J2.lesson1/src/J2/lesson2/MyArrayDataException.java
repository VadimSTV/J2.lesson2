package J2.lesson2;

public class MyArrayDataException extends Throwable {
    public String i;
    public String j;

    public MyArrayDataException(int i, int j) {
    }
}
