package J2.lesson1.animals.obstacles;


import J2.lesson1.animals.Participant.Participant;

public abstract class Obstacle {

    public abstract void doIt(Participant animal);
}
